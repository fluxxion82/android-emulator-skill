#!/usr/bin/env python3
"""ANR watcher session storage — own dir layout, no ProgressiveCache reuse.

Ported from the iOS HangBuster session store (``hang_sessions.py``); the
filesystem machinery is platform-agnostic, only the storage root, env-var
prefix, and session-id prefix are retargeted for Android.

Each session is a directory under
``~/.android-emulator-skill/anr-sessions/<id>/`` containing ``meta.json``
(config + pid + status), ``events.jsonl`` (append-only normalised events), and
``summary.json`` (post-stop).

The parent creates the directory and writes initial meta, with a random
``worker_token`` it hands the worker on its command line. The detached worker
updates meta with its own pid and start time (avoids pidfile race) and appends
to events.jsonl. ``--stop`` SIGTERMs the worker -- only once the process at
that pid has been shown to still be it -- drains events, builds a
``SessionSummary``, and writes ``summary.json``.

Storage root is overridable for tests via the ``ANDROID_EMU_ANR_HOME`` env var
or the ``SessionStore(base_dir=...)`` constructor argument, so the suite never
touches the real home directory.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import secrets
import signal
import subprocess
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

from common.anr_pipeline import (
    FINGERPRINT_VERSION,
    SessionSummary,
    SummaryBuilder,
    event_from_jsonl,
    summary_from_json,
    summary_to_json,
)
from common.env_config import env_int

# === CONSTANTS ===

_STATUS_PENDING = "pending"
_STATUS_RUNNING = "running"
_STATUS_STOPPED = "stopped"
_STATUS_CRASHED = "crashed"

_DURATION_RE = re.compile(r"(\d+)([smhd])$")

# How the worker's command line carries its token (see ``SessionMeta``).
WORKER_TOKEN_FLAG = "--worker-token"
# One `ps` question about the host's process table.
PS_TIMEOUT_SECONDS = 5


def _default_sessions_dir() -> Path:
    """Resolve the storage root, honouring the ``ANDROID_EMU_ANR_HOME`` override.

    Read lazily (not at import time) so tests that set the env var in a fixture
    take effect, and so each ``SessionStore()`` picks up the current value.
    """
    override = os.environ.get("ANDROID_EMU_ANR_HOME", "").strip()
    if override:
        return Path(override).expanduser() / "anr-sessions"
    return Path("~/.android-emulator-skill/anr-sessions").expanduser()


def _default_ttl_hours() -> int:
    """Session prune age, read lazily so env overrides apply per call."""
    return env_int("ANDROID_EMU_ANR_SESSION_TTL_HOURS", 24)


# === TYPES ===


@dataclass
class SessionMeta:
    """Parent + worker writes to meta.json."""

    session_id: str
    started_at: str
    started_at_ms: int
    args: dict
    pid: int | None = None
    status: str = _STATUS_PENDING
    stopped_at: str | None = None
    stopped_at_ms: int | None = None
    extras: dict = field(default_factory=dict)
    # The fingerprint version the session's events are captured under. A
    # session recorded before this was kept is v1, the only version there was.
    fingerprint_version: int = 1
    # Who the worker is, beyond a pid the OS reuses: a random token the parent
    # puts on the worker's command line, and the start time `ps` gave for the
    # pid when the worker claimed it. A pid that no longer shows both is not
    # this session's worker, and is never signalled.
    worker_token: str | None = None
    worker_started: str | None = None

    def to_json(self) -> dict:
        return {
            "session_id": self.session_id,
            "started_at": self.started_at,
            "started_at_ms": self.started_at_ms,
            "args": self.args,
            "pid": self.pid,
            "status": self.status,
            "stopped_at": self.stopped_at,
            "stopped_at_ms": self.stopped_at_ms,
            "extras": self.extras,
            "fingerprint_version": self.fingerprint_version,
            "worker_token": self.worker_token,
            "worker_started": self.worker_started,
        }

    @classmethod
    def from_json(cls, payload: dict) -> SessionMeta:
        return cls(
            session_id=payload["session_id"],
            started_at=payload["started_at"],
            started_at_ms=payload["started_at_ms"],
            args=payload.get("args", {}),
            pid=payload.get("pid"),
            status=payload.get("status", _STATUS_PENDING),
            stopped_at=payload.get("stopped_at"),
            stopped_at_ms=payload.get("stopped_at_ms"),
            extras=payload.get("extras", {}),
            fingerprint_version=payload.get("fingerprint_version", 1),
            worker_token=payload.get("worker_token"),
            worker_started=payload.get("worker_started"),
        )


def _ps(pid: int, field: str) -> str | None:
    """One ``ps`` field of host process ``pid``; None when ``ps`` lists no such process.

    In the C locale and UTC, so the start time reads the same whoever asks --
    the worker when it claims its pid, a later `--stop` in another shell.

    Raises:
        OSError: ``ps`` could not be run.
        subprocess.TimeoutExpired: It did not answer in ``PS_TIMEOUT_SECONDS``.
    """
    result = subprocess.run(
        ["ps", "-o", f"{field}=", "-p", str(pid)],
        capture_output=True,
        text=True,
        timeout=PS_TIMEOUT_SECONDS,
        check=False,
        env={**os.environ, "LC_ALL": "C", "TZ": "UTC"},
    )
    answer = result.stdout.strip()
    return answer if result.returncode == 0 and answer else None


def process_started(pid: int) -> str | None:
    """When host process ``pid`` started (``ps -o lstart``); None when unknown."""
    try:
        return _ps(pid, "lstart")
    except (OSError, subprocess.SubprocessError):
        return None


def worker_mismatch(meta: SessionMeta) -> str | None:
    """Why the process at ``meta.pid`` is not (or cannot be shown to be) the session's worker.

    None when it is: alive, its command line carrying the session's
    ``worker_token``, and started when the worker claimed the pid. A crashed
    or killed worker's pid is the OS's to give to anything; signalling it
    without this check sent SIGTERM to whatever held the pid by then (Codex
    review of PR #34).
    """
    pid = meta.pid
    try:
        command = _ps(pid, "command")
        started = _ps(pid, "lstart")
    except (OSError, subprocess.SubprocessError) as error:
        return f"`ps` could not say what pid {pid} is ({error})"
    if command is None or started is None:
        return f"pid {pid} has exited"
    if not meta.worker_token or f"{WORKER_TOKEN_FLAG} {meta.worker_token}" not in command:
        return (
            f"pid {pid} is another process now (its command line has no "
            f"{WORKER_TOKEN_FLAG} for this session)"
        )
    if started != meta.worker_started:
        return (
            f"pid {pid} started at {started}, not when this session's worker did "
            f"({meta.worker_started or 'unrecorded'})"
        )
    return None


# === SESSION STORE ===


class SessionStore:
    """Filesystem-backed session repository."""

    def __init__(self, base_dir: Path | str | None = None):
        self.base_dir = Path(base_dir).expanduser() if base_dir else _default_sessions_dir()
        self.base_dir.mkdir(parents=True, exist_ok=True)

    # === PUBLIC API ===

    def create(self, args: dict) -> SessionMeta:
        """Generate id + dir + initial meta.json. Caller detaches the worker next."""
        session_id = _generate_session_id()
        session_dir = self.base_dir / session_id
        session_dir.mkdir(parents=True, exist_ok=False)
        # Empty events file so the worker can `open(..., 'a')` cleanly.
        (session_dir / "events.jsonl").touch()
        now = datetime.now()
        meta = SessionMeta(
            session_id=session_id,
            started_at=now.isoformat(),
            started_at_ms=int(now.timestamp() * 1000),
            args=args,
            status=_STATUS_PENDING,
            # The worker this session's events come from is spawned from the
            # same code, so this is the version they are fingerprinted under.
            fingerprint_version=FINGERPRINT_VERSION,
            worker_token=secrets.token_hex(8),
        )
        self._write_meta(meta)
        return meta

    def wait_for_worker(self, session_id: str, timeout_seconds: float = 2.0) -> SessionMeta:
        """Poll meta.json until the worker has registered, or time out. Raises on timeout.

        Registered is running -- or crashed after it claimed the session: a
        worker can claim and be marked crashed between two polls, and read as
        one that never started ("did not register", exit 1) where its own
        failure was the answer (CI on PR #42). The claim left
        ``worker_started`` (kept by ``mark_crashed``), and the worker persists
        its counters before it marks the session crashed; either shows it.
        """
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            meta = self.load_meta(session_id)
            if meta.status == _STATUS_RUNNING and meta.pid:
                return meta
            if meta.status == _STATUS_CRASHED and (
                meta.worker_started or "line_counters" in meta.extras
            ):
                return meta
            time.sleep(0.05)
        raise TimeoutError(f"Worker for {session_id} did not register within {timeout_seconds}s")

    def claim_worker(self, session_id: str, pid: int) -> SessionMeta:
        """Called by worker on startup. Writes pid, its start time and status=running."""
        meta = self.load_meta(session_id)
        meta.pid = pid
        meta.worker_started = process_started(pid)
        meta.status = _STATUS_RUNNING
        self._write_meta(meta)
        return meta

    def persist_worker_counters(self, session_id: str, counters: dict) -> None:
        """Worker calls this at shutdown to flush its line counters into meta.

        Re-reads meta from disk so a concurrent terminal status — ``stopped``
        from the parent's ``stop()`` or ``crashed`` from this worker's own
        ``mark_crashed`` — is not clobbered back to ``running``.
        """
        meta = self.load_meta(session_id)
        meta.extras["line_counters"] = counters
        if meta.status not in (_STATUS_STOPPED, _STATUS_CRASHED):
            meta.status = _STATUS_RUNNING
        self._write_meta(meta)

    def stop(self, session_id: str, summary: SessionSummary) -> SessionMeta:
        """Mark session stopped and persist the computed summary."""
        meta = self.load_meta(session_id)
        meta.status = _STATUS_STOPPED
        now = datetime.now()
        meta.stopped_at = now.isoformat()
        meta.stopped_at_ms = int(now.timestamp() * 1000)
        self._write_meta(meta)
        self._write_summary(session_id, summary)
        return meta

    def mark_crashed(self, session_id: str) -> None:
        """Best-effort: tag a session whose worker exited without a summary.

        Records ``stopped_at`` / ``stopped_at_ms`` so capture-duration math in
        ``build_summary`` and ``--list-sessions`` reflects when the worker
        actually died, not when the session was finally inspected. Clears the
        pid: the worker is exiting, and its pid is about to be the OS's to reuse.
        """
        try:
            meta = self.load_meta(session_id)
        except FileNotFoundError:
            return
        meta.status = _STATUS_CRASHED
        meta.pid = None
        now = datetime.now()
        meta.stopped_at = now.isoformat()
        meta.stopped_at_ms = int(now.timestamp() * 1000)
        self._write_meta(meta)

    def forget_worker(self, session_id: str) -> None:
        """The worker has exited: drop its pid, which the OS may now give to anything."""
        meta = self.load_meta(session_id)
        if meta.pid is not None:
            meta.pid = None
            self._write_meta(meta)

    def signal_worker(self, session_id: str, sig: int = signal.SIGTERM) -> bool:
        """Send ``sig`` to the session's worker, once it is shown to be it. True if delivered.

        A recorded pid that is not the worker (:func:`worker_mismatch`) is never
        signalled: the reason is kept in ``extras["worker_gone"]`` for the
        caller to say, and the pid is forgotten -- unless `ps` could not answer,
        when the worker may still be alive and its pid is kept.

        When the pid is kept and may still be the worker -- `ps` could not say,
        or the signal was refused -- why is kept in
        ``extras["worker_unresolved"]`` too: not delivered is then not "gone",
        and --stop must not answer as if the worker had ended (review of PR
        #42: it saved a summary at exit 0 while the worker went on).
        """
        meta = self.load_meta(session_id)
        if not meta.pid:
            return False
        unresolved = meta.extras.pop("worker_unresolved", None)
        mismatch = worker_mismatch(meta)
        if mismatch is not None:
            meta.extras["worker_gone"] = mismatch
            if mismatch.startswith("`ps`"):
                meta.extras["worker_unresolved"] = mismatch
            else:
                meta.pid = None
            self._write_meta(meta)
            return False
        try:
            os.kill(meta.pid, sig)
        except ProcessLookupError:
            if unresolved is not None:
                self._write_meta(meta)
            return False
        except PermissionError as error:
            meta.extras["worker_unresolved"] = f"pid {meta.pid} could not be signalled ({error})"
            self._write_meta(meta)
            return False
        if unresolved is not None:
            self._write_meta(meta)
        return True

    def load_meta(self, session_id: str) -> SessionMeta:
        path = self._meta_path(session_id)
        if not path.exists():
            raise FileNotFoundError(f"No meta.json for session {session_id}")
        with open(path) as handle:
            return SessionMeta.from_json(json.load(handle))

    def load_summary(self, session_id: str) -> SessionSummary | None:
        path = self._summary_path(session_id)
        if not path.exists():
            return None
        with open(path) as handle:
            return summary_from_json(json.load(handle))

    def read_events(self, session_id: str) -> list:
        """Read all events.jsonl lines, returning NormalisedEvent instances.

        Skips non-event sentinel lines (e.g. ``{"event": "stream_ended"}``).
        """
        path = self._events_path(session_id)
        if not path.exists():
            return []
        events = []
        with open(path) as handle:
            for raw in handle:
                line = raw.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue
                # Skip non-event sentinel lines (e.g. {"event": "stream_ended"}).
                if "event" in payload and "fingerprint" not in payload:
                    continue
                try:
                    events.append(event_from_jsonl(line))
                except (json.JSONDecodeError, KeyError):
                    continue
        return events

    def events_path(self, session_id: str) -> Path:
        """Worker writes here. Public so the worker can open it line-buffered."""
        return self._events_path(session_id)

    def session_dir(self, session_id: str) -> Path:
        """Directory for one session, validating the id first.

        Session ids reach this from argv -- ``anr_watcher --get-details SID``
        and ``--stop SID`` -- and joining an unvalidated string onto the storage
        root lets a traversing id read ``<root>/../../x/meta.json`` and, on the
        stop path, *write* meta.json and summary.json there.

        Args:
            session_id: Caller-supplied session id.

        Returns:
            The session directory, always directly under the storage root.

        Raises:
            ValueError: If the id is not a plain session id.
        """
        if not session_id or not _SAFE_SESSION_ID_RE.fullmatch(session_id):
            raise ValueError(
                f"Invalid session id {session_id!r}. Expected a plain id like "
                f"'anr-20260617-143000-a1b2' (letters, digits, dash, underscore)."
            )
        return self.base_dir / session_id

    def session_total_bytes(self, session_id: str) -> int:
        """Sum of all files under a session dir. Used by aggregate-cap pruning."""
        total = 0
        session_path = self.session_dir(session_id)
        if not session_path.exists():
            return 0
        for path in session_path.rglob("*"):
            if path.is_file():
                with contextlib.suppress(OSError):
                    total += path.stat().st_size
        return total

    def prune_to_aggregate_cap(self, max_bytes: int) -> int:
        """Drop oldest sessions until total bytes ≤ max_bytes. Returns deletions.

        Pairs with ``prune_expired``: TTL handles age, this handles disk usage
        when activity outpaces TTL. Both are called automatically on every
        ``create`` so the user never has to clean up manually.
        """
        if max_bytes <= 0:
            return 0
        # Oldest first — deletion order.
        entries: list[tuple[int, str, int]] = []  # (started_at_ms, session_id, bytes)
        total = 0
        for entry in self.base_dir.iterdir():
            if not entry.is_dir():
                continue
            try:
                meta = self.load_meta(entry.name)
            except (FileNotFoundError, json.JSONDecodeError):
                continue
            size = self.session_total_bytes(entry.name)
            total += size
            entries.append((meta.started_at_ms, entry.name, size))
        if total <= max_bytes:
            return 0
        entries.sort(key=lambda e: e[0])  # oldest first
        deleted = 0
        for _, session_id, size in entries:
            if total <= max_bytes:
                break
            _remove_tree(self.session_dir(session_id))
            total -= size
            deleted += 1
        return deleted

    def list_sessions(self) -> list[SessionMeta]:
        """All session metas, newest first."""
        metas: list[SessionMeta] = []
        for entry in self.base_dir.iterdir():
            if not entry.is_dir():
                continue
            try:
                metas.append(self.load_meta(entry.name))
            except (FileNotFoundError, json.JSONDecodeError):
                continue
        metas.sort(key=lambda m: m.started_at_ms, reverse=True)
        return metas

    def clear(self, older_than: str | None = None) -> int:
        """Delete session dirs. ``older_than`` is a duration string like ``24h``."""
        cutoff_ms = _resolve_cutoff_ms(older_than) if older_than else None
        deleted = 0
        for entry in self.base_dir.iterdir():
            if not entry.is_dir():
                continue
            try:
                meta = self.load_meta(entry.name)
            except (FileNotFoundError, json.JSONDecodeError):
                _remove_tree(entry)
                deleted += 1
                continue
            if cutoff_ms is None or meta.started_at_ms <= cutoff_ms:
                _remove_tree(entry)
                deleted += 1
        return deleted

    def prune_expired(self, ttl_hours: int | None = None) -> int:
        """Remove sessions older than ttl. Called on every ``create``."""
        ttl = ttl_hours if ttl_hours is not None else _default_ttl_hours()
        cutoff = int((datetime.now() - timedelta(hours=ttl)).timestamp() * 1000)
        return self._clear_older_than_ms(cutoff)

    # === SUMMARY HELPERS ===

    def build_summary(
        self,
        session_id: str,
        matched_lines: int = 0,
        total_lines: int = 0,
        dropped_below_threshold: int = 0,
        extras: dict | None = None,
        top_n: int | None = None,
    ) -> SessionSummary:
        """Convenience: read events.jsonl and run the pipeline through SummaryBuilder.

        Duration prefers ``meta.stopped_at_ms`` (set on both ``stop()`` and
        ``mark_crashed()``) so summaries for crashed/stopped sessions reflect
        the actual capture window, not the time of inspection. Live sessions
        without ``stopped_at_ms`` fall back to ``now`` as before.
        """
        meta = self.load_meta(session_id)
        events = self.read_events(session_id)
        end_ms = meta.stopped_at_ms or int(datetime.now().timestamp() * 1000)
        duration_ms = end_ms - meta.started_at_ms
        builder = SummaryBuilder(
            session_id=session_id,
            started_at=meta.started_at,
            duration_ms=max(0, duration_ms),
            matched_lines=matched_lines,
            total_lines=total_lines,
            dropped_below_threshold=dropped_below_threshold,
            extras=extras or {},
            # The capture's version, not this code's: `--stop` on a session
            # recorded before a fingerprint change must not stamp its old
            # fingerprints with the new version (review of PR #26).
            fingerprint_version=meta.fingerprint_version,
        )
        return builder.build(events, top_n=top_n)

    # === PRIVATE ===

    def _meta_path(self, session_id: str) -> Path:
        return self.session_dir(session_id) / "meta.json"

    def _events_path(self, session_id: str) -> Path:
        return self.session_dir(session_id) / "events.jsonl"

    def _summary_path(self, session_id: str) -> Path:
        return self.session_dir(session_id) / "summary.json"

    def _write_meta(self, meta: SessionMeta) -> None:
        path = self._meta_path(meta.session_id)
        tmp = path.with_suffix(".json.tmp")
        # Atomic write — concurrent reads (e.g. the parent polling) never see a half-file.
        # fsync before replace makes the new contents durable, not just atomically renamed.
        with open(tmp, "w") as handle:
            json.dump(meta.to_json(), handle, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        tmp.replace(path)

    def _write_summary(self, session_id: str, summary: SessionSummary) -> None:
        path = self._summary_path(session_id)
        tmp = path.with_suffix(".json.tmp")
        with open(tmp, "w") as handle:
            json.dump(summary_to_json(summary), handle, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        tmp.replace(path)

    def _clear_older_than_ms(self, cutoff_ms: int) -> int:
        deleted = 0
        for entry in self.base_dir.iterdir():
            if not entry.is_dir():
                continue
            try:
                meta = self.load_meta(entry.name)
            except (FileNotFoundError, json.JSONDecodeError):
                _remove_tree(entry)
                deleted += 1
                continue
            if meta.started_at_ms <= cutoff_ms:
                _remove_tree(entry)
                deleted += 1
        return deleted


# Session ids are generated as "anr-<YYYYmmdd>-<HHMMSS>-<4 hex>". Anything
# outside this alphabet cannot be one, and a separator or ".." would let an
# id address paths outside the storage root.
_SAFE_SESSION_ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]*")


# === MODULE-LEVEL HELPERS ===


def _generate_session_id() -> str:
    """``anr-YYYYMMDD-HHmmss-XXXX`` — random hex suffix avoids same-second collisions."""
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    suffix = secrets.token_hex(2)
    return f"anr-{timestamp}-{suffix}"


def _resolve_cutoff_ms(duration_str: str) -> int:
    """Parse e.g. ``24h``, ``30m`` and return the epoch-ms threshold."""
    match = _DURATION_RE.match(duration_str.strip().lower())
    if not match:
        raise ValueError(f"Invalid duration: {duration_str!r}. Use 30s/5m/24h/7d.")
    value, unit = int(match.group(1)), match.group(2)
    seconds = value * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
    cutoff = datetime.now() - timedelta(seconds=seconds)
    return int(cutoff.timestamp() * 1000)


def _remove_tree(path: Path) -> None:
    """rm -rf path. Used for session-dir cleanup."""
    for child in path.iterdir():
        if child.is_dir():
            _remove_tree(child)
        else:
            with contextlib.suppress(FileNotFoundError):
                child.unlink()
    with contextlib.suppress(OSError):
        path.rmdir()
